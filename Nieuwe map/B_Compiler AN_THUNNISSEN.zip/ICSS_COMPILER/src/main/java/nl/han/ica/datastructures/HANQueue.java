package nl.han.ica.datastructures;

public class HANQueue implements IHANQueue{
    @Override
    public void clear() {

    }

    @Override
    public boolean isEmpty() {
        return false;
    }

    @Override
    public void enqueue(Object value) {

    }

    @Override
    public Object dequeue() {
        return null;
    }

    @Override
    public Object peek() {
        return null;
    }

    @Override
    public int getSize() {
        return 0;
    }
}
