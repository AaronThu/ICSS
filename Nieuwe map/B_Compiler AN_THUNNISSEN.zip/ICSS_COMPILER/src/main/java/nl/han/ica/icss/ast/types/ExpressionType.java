package nl.han.ica.icss.ast.types;

public enum ExpressionType {
    PIXEL,
    PERCENTAGE,
    COLOR,
    SCALAR,
    UNDEFINED,
    BOOL
}
